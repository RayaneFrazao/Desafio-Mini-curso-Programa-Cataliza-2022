# Minicurso
Minicurso do Catalisa 2022 - Como consumir a API do Rick And Morty
